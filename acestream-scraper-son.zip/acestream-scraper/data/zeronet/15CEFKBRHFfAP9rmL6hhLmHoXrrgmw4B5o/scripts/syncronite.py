#!/usr/bin/env python3

import os
import re
import json
import time
import shutil
import requests
from io import StringIO
from tempfile import NamedTemporaryFile
from datetime import datetime

# Check if it's the second minute of the hour
current_minute = datetime.now().minute
skip_time_diff_function = current_minute == 1

ZERONET_ROOT_DIR = os.path.join(os.environ['HOME'], "apps", "zeronet")
ZERONET_ADDRESS = "15CEFKBRHFfAP9rmL6hhLmHoXrrgmw4B5o"
SyncroniteDir = os.path.join(ZERONET_ROOT_DIR, "data", ZERONET_ADDRESS)
CLEARNET_TRACKERS = [
    "https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_all_ip.txt",
    "https://ngosang.github.io/trackerslist/trackers_all_ip.txt",
    "https://cdn.jsdelivr.net/gh/ngosang/trackerslist@master/trackers_all_ip.txt"
]
NEIL_ALEXANDER = "https://publicpeers.neilalexander.dev/"
OUTFILE_1A = os.path.join(SyncroniteDir, "cache", "1", "_h_.html")
OUTFILE_2A = os.path.join(SyncroniteDir, "cache", "2", "publicnodes.json")
OUTFILE_2B = os.path.join(SyncroniteDir, "cache", "2", "index.html")
TEMPFILE_1A = StringIO()
TEMPFILE_2A = StringIO()
TEMPFILE_2B = StringIO()
BLACKLIST_FILE = os.path.join(SyncroniteDir, "cache", "1", "blacklist.txt")
PERMABANNED_FILE = os.path.join(SyncroniteDir, "cache", "1", "permabanned.txt")
TEMP_STATS_FILE = StringIO()

# Exit this script if it is running too soon after trackers file was updated
if not skip_time_diff_function:
    epoch_now = int(time.time())
    content_file = os.path.join(SyncroniteDir, "content.json")

    with open(content_file, 'r') as f:
        content_data = json.load(f)

    epoch_then = content_data.get('modified', 0)
    diff = epoch_now - epoch_then

    if diff < 3540:
        print(f"Difference between now and then is less than 3540 seconds. ({diff} seconds)")
        exit()
    else:
        print(f"Difference between now and then is 3540 seconds or more. ({diff} seconds)")
        pass

# DIR1

# Get clearnet trackers
print("Fetching clearnet trackers...")
for TRACKER_URL in CLEARNET_TRACKERS:
    response = requests.get(TRACKER_URL)
    if response.status_code == 200:
        f = TEMPFILE_1A
        f.write(response.text)
        break

# If none of the clearnet trackers URLs worked
if len(TEMPFILE_1A.getvalue()) == 0:
    print("None of the clearnet trackers URLs worked. Exiting...")
    exit(1)

# Replace the old clearnet trackers file with the new one
print("Replacing the old clearnet trackers file with the new one...")
with open(OUTFILE_1A, 'w') as outfile:
    outfile.write(TEMPFILE_1A.getvalue())

# Sort _h_.html
with open(OUTFILE_1A, 'r') as file:
    lines = sorted(file.readlines())
with open(OUTFILE_1A, 'w') as file:
    file.writelines(lines)

# Remove blank lines in between from _h_.html
with open(OUTFILE_1A, 'r') as file:
    lines = [line for line in file.readlines() if line.strip()]
with open(OUTFILE_1A, 'w') as file:
    file.writelines(lines)

# Remove last empty line from _h_.html
with open(OUTFILE_1A, 'rb+') as file:
    file.seek(-1, os.SEEK_END)
    if file.read(1) == b'\n':
        file.seek(-1, os.SEEK_END)
        file.truncate()

def add_successful_shared_trackers_to_zero_html():
    stats_url = "http://127.0.0.1:43110/Stats"
    try:
        response = requests.get(stats_url, headers={"Accept": "text/html"}, timeout=60)
    except requests.exceptions.Timeout:
        print("Request timed out. Please try again later.")
        pass

    content = response.text
    f = TEMP_STATS_FILE
    f.write(content)

    zero_html_file = os.path.join(SyncroniteDir, "cache", "1", "zero.html")
    successful_trackers = re.findall(r'<td>(zero://.*?)<\/td><td>.*?<\/td><td>.*?<\/td><td>.*?<\/td><td>0<\/td>', content)

    with open(zero_html_file, 'a') as outfile:
        for tracker in successful_trackers:
            outfile.write(tracker + '\n')

    # Remove duplicates, sort by line length, and then sort alphabetically
    with open(zero_html_file, 'r') as file:
        lines = sorted(set(file.readlines()), key=lambda x: (len(x), x))
    with open(zero_html_file, 'w') as file:
        file.writelines(lines)

def remove_trackers_from_zero_html_on_error():

  stats_url = "http://127.0.0.1:43110/Stats"

  print("Fetching stats page...")

  try:
    response = requests.get(stats_url, timeout=10)
  except requests.Timeout:
    print("Request timed out")
    return

  content = response.text

  pattern = r'zero://[^<]+</td><td>[1-9][0-9]*</td>'

  print("Finding trackers with errors...")

  trackers_with_errors = re.findall(pattern, content)

  home = os.environ['HOME']

  zero_html_file = os.path.join(home, "apps", "zeronet", "data", "15CEFKBRHFfAP9rmL6hhLmHoXrrgmw4B5o", "cache", "1", "zero.html") 

  print("Filtering trackers...")

  with open(zero_html_file, 'r') as f:
    lines = f.readlines()

  filtered_lines = []
  for line in lines:
    if line.strip() not in trackers_with_errors:
      filtered_lines.append(line)

  print("Writing filtered data...")
  
  with open(zero_html_file, 'w') as f:
    f.writelines(filtered_lines)

  print("Done!")

# Combine trackers files into Syncronite.html
trackers_files = [
    os.path.join(SyncroniteDir, "cache", "1", "zero.html"),
    OUTFILE_1A
]

with open(os.path.join(SyncroniteDir, "cache", "1", "Syncronite.html"), 'w') as outfile:
    for fname in trackers_files:
        with open(fname, 'r') as infile:
            outfile.write(infile.read())

def add_trackers_to_blacklist():
    stats_url = "http://127.0.0.1:43110/Stats"
    try:
        response = requests.get(stats_url, headers={"Accept": "text/html"}, timeout=60)
    except requests.exceptions.Timeout:
        print("Request timed out. Please try again later.")
        pass

    content = response.text

    f = TEMP_STATS_FILE
    f.write(content)

    trackers_info = re.findall(r'<td>((?:zero|udp|http|https)://[^<]+)</td><td>([0-9]+)</td><td>([0-9]+)', content)

    with open(BLACKLIST_FILE, "r") as f:
        blacklist = f.readlines()

    with open(BLACKLIST_FILE, "a") as f:
        for info in trackers_info:
            tracker, errors, num_requests = info
            if errors == num_requests and errors != "0":
                if tracker.strip() not in blacklist:
                    f.write(tracker.strip() + "\n")

    # Remove duplicates and sort blacklist
    with open(BLACKLIST_FILE, 'r') as file:
        lines = sorted(set(file.readlines()))
    with open(BLACKLIST_FILE, 'w') as file:
        file.writelines(lines)

def remove_trackers_from_blacklist():
    temp_stats_content = TEMP_STATS_FILE.getvalue()
    with open(BLACKLIST_FILE, 'r') as blacklist, open(PERMABANNED_FILE, 'r') as permabanned:
        blacklist_lines = blacklist.readlines()
        permabanned_lines = [line.strip() for line in permabanned.readlines()]

    trackers = re.findall(r'<td>(zero://.*?)<\/td><td>.*?<\/td><td>.*?<\/td><td>.*?<\/td><td>0<\/td>', temp_stats_content)
    trackers_to_remove = []

    for tracker in trackers:
        if tracker not in permabanned_lines:
            trackers_to_remove.append(tracker)

    with open(BLACKLIST_FILE, 'w') as blacklist:
        for line in blacklist_lines:
            if line.strip() not in trackers_to_remove:
                blacklist.write(line)

        # Add the permabanned trackers to the blacklist
        for permabanned_tracker in permabanned_lines:
            if permabanned_tracker not in blacklist_lines:
                blacklist.write(permabanned_tracker + '\n')

# Call the add_successful_shared_trackers_to_zero_html function
print("Adding successful shared trackers to zero.html...")
add_successful_shared_trackers_to_zero_html()

# Call the remove_trackers_from_zero_html_on_error function
print("Removing trackers from zero.html if there are any errors...")
remove_trackers_from_zero_html_on_error()

# Call the remove_trackers_from_blacklist function
print("Removing trackers with 0 errors from the blacklist...")
remove_trackers_from_blacklist()

# Call the add_trackers_to_blacklist function
print("Adding trackers to the blacklist...")
add_trackers_to_blacklist()

# Remove trackers that don't work
print("Removing trackers that don't work...")
with open(os.path.join(SyncroniteDir, "cache", "1", "Syncronite.html"), "r") as f:
    lines = f.readlines()

with open(BLACKLIST_FILE, "r") as f:
    blacklist = [line.strip() for line in f.readlines()]

filtered_lines = []
for line in lines:
    should_write = True
    for pattern in blacklist:
        if re.search(re.escape(pattern), line):
            should_write = False
            break
    if should_write:
        filtered_lines.append(line)

with open(os.path.join(SyncroniteDir, "cache", "1", "Syncronite.html"), "w") as f:
    for line in filtered_lines:
        f.write(line)

# DIR2

# Get public nodes list
print("Fetching public nodes list...")
response = requests.get(NEIL_ALEXANDER + "publicnodes.json")
if response.status_code == 200:
    f = TEMPFILE_2A
    f.write(response.text)
else:
    print("Failed to fetch public nodes list.")
    pass

# Replace the old public nodes file with the new one
print("Replacing the old public nodes file with the new one...")
with open(OUTFILE_2A, 'w') as outfile:
    outfile.write(TEMPFILE_2A.getvalue())

# Get index page of public peers site
response = requests.get(NEIL_ALEXANDER + "index.html")
if response.status_code == 200:
    f = TEMPFILE_2B
    f.write(response.text)
else:
    pass

# Replace the old index.html file with the new one
with open(OUTFILE_2B, 'w') as outfile:
    outfile.write(TEMPFILE_2B.getvalue())

# Make functional improvements to index.html
with open(os.path.join(SyncroniteDir, "cache", "2", "index.html"), "r") as f:
    index_html = f.read()

index_html = index_html.replace('<html>', '<!DOCTYPE html>\n<html lang="en">')
index_html = index_html.replace('<br />', '<br>')
index_html = index_html.replace('<title>Public Peers</title>', '<title>Public Peers</title>\n<meta name="viewport" content="width=device-width, initial-scale=.8, user-scalable=0, minimum-scale=.8, maximum-scale=.8">\n<link rel="icon" type="image/png" sizes="200x200" href="Yggdrasil.png">')
index_html = index_html.replace('<body>', '<body class="{themeclass}">')
index_html = re.sub(r'(<head>)', r'\1<base target="_top">', index_html)
index_html = re.sub(r'(^<style>.*$)', r'<link rel="stylesheet" type="text/css" href="index.css?v={site_modified}">\n<script type="text/javascript" src="color-scheme.js"></script>\n\1', index_html, flags=re.MULTILINE)
index_html = index_html.replace('<table>', '<p><div>Simply tap or click on a public peer address to copy it.</div><table>')
index_html = re.sub(r'^.*<script defer src="https://static.cloudflareinsights.com/beacon.min.js.*\n', '', index_html, flags=re.MULTILINE)
index_html = re.sub(r'</body>', r'<script type="text/javascript" src="index.js?v={site_modified}"></script>\n<script type="text/javascript" src="../../js/ZeroFrame.js?v=1"></script>\n</body>', index_html)

with open(os.path.join(SyncroniteDir, "cache", "2", "index.html"), "w") as f:
    f.write(index_html)

# Remove last empty line from index.html
with open(os.path.join(SyncroniteDir, "cache", "2", "index.html"), 'rb+') as file:
    file.seek(-1, os.SEEK_END)
    if file.read(1) == b'\n':
        file.seek(-1, os.SEEK_END)
        file.truncate()

home = os.environ['HOME']
venv_path = os.path.join(home, "venv", "bin") 

# Sign and publish 
print("Signing and publishing...")
cmd = f"{venv_path}/python {os.path.join(ZERONET_ROOT_DIR, 'zeronet.py')} siteSign {ZERONET_ADDRESS} --publish"
os.system(cmd)

print("Script completed.")

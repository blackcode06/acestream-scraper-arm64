# ZeroHello

Homepage and visited site manager for [ZeroNet](https://github.com/HelloZeroNet/ZeroNet).

ZeroNet address: http://127.0.0.1:43110/1HeLLo4uzjaLetFx6NH3PMwFP3qbRbTf3D

## Screenshot

![Screenshot](http://i.imgur.com/H60OAHY.png)

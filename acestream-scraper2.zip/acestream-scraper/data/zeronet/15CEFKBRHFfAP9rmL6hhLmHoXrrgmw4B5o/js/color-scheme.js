function isNotInsideIframe() {
    try {
        return window.self === window.top;
    } catch (e) {
        return false;
    }
}

async function fetchAndApplyStyles() {
    try {
        const response = await fetch('color-scheme.css');

        if (response.ok) {
            const cssText = await response.text();
            const style = document.createElement('style');
            style.innerHTML = cssText;
            document.head.appendChild(style);
        } else {
            console.error('Failed to fetch color-scheme.css');
        }
    } catch (error) {
        console.error('Error fetching color-scheme.css:', error);
    }
}

if (isNotInsideIframe()) {
    fetchAndApplyStyles();
}
from flask_restx import Namespace, Resource, fields, reqparse
from flask import Response, request, current_app
import os
from app.models import AcestreamChannel
from app.services.playlist_service import PlaylistService
from app.repositories import URLRepository
from app.services import ScraperService

api = Namespace('playlists', description='Playlist management operations')

playlist_parser = reqparse.RequestParser()
playlist_parser.add_argument('refresh', type=bool, required=False, default=False,
                          help='Whether to refresh the playlist before returning')
playlist_parser.add_argument('search', type=str, required=False,
                          help='Filter channels by name')

@api.route('/m3u')
class M3UPlaylist(Resource):
    @api.doc('get_m3u_playlist')
    @api.expect(playlist_parser)
    def get(self):
        """Get M3U playlist of all channels"""
        args = playlist_parser.parse_args()
        refresh = args.get('refresh', False)
        search = args.get('search', None)
        
        playlist_service = PlaylistService()
        playlist = playlist_service.generate_playlist(search_term=search)
        
        # Always save the playlist as playlist.m3u
        playlist_path = os.path.join(current_app.root_path, 'playlist.m3u')
        
        # Save the playlist to the specified file
        with open(playlist_path, 'w', encoding='utf-8') as f:
            f.write(playlist)
        
        # Serve the playlist with a fixed filename
        return Response(
            playlist,
            mimetype="audio/x-mpegurl",
            headers={"Content-Disposition": "attachment; filename=playlist.m3u"}
        )

@api.route('/channels')
class PlaylistChannels(Resource):
    @api.doc('get_playlist_channels')
    def get(self):
        """Get list of all channels suitable for playlist generation"""
        channels = AcestreamChannel.query.filter_by(status='active').all()
        
        result = []
        for channel in channels:
            result.append({
                'id': channel.id,
                'name': channel.name,
                'is_online': channel.is_online,
                'group': channel.group or 'Uncategorized',
                'logo': channel.logo,
                'tvg_id': channel.tvg_id,
                'tvg_name': channel.tvg_name
            })
            
        return result
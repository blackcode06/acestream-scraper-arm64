function isNotInsideIframe() {
    try {
        return window.self === window.top;
    } catch (e) {
        return false;
    }
}

function isNotLocalhost() {
    return window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1';
}

if (isNotInsideIframe() && isNotLocalhost()) {
    const style = document.createElement('style');
    style.innerHTML = `
        @media (prefers-color-scheme: light) {
            table tr.statusup, div, h1, table tr th#country, table tr.statusdown, li {
                color: #000!important
            }
        }

        @media (prefers-color-scheme: dark) {
            table tr.statusup, div, h1, table tr th#country, table tr.statusdown, li {
                color: #fff!important
            }
        }

        @media (prefers-color-scheme: light) {
            body, td {
                background: #fff
            }
        }

        @media (prefers-color-scheme: dark) {
            body, td {
                background: #000
            }
        }
    `;
    document.head.appendChild(style);
}